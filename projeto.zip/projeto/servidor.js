//Adicionado bibliotecas e as preparando para o servidor
const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const app = express();
app.use(cors());
app.use(express.json());
//Iniciando ligação ao banco de dados
const db = mysql.createConnection({
    host: '192.168.171.210',
    user: 'bd-innovatec',
    password: 'bdinnovatec',
    database: 'bd-innovatec'

});
//Conecção ao banco de dados
db.connect((err) => {
    if(err) {
        console.error('Erro ao conectar no banco de dados:', err);
        return;
    }
    console.log('Conectado ao banco de dados.');
});
//Adicona (cria) uma rota no servidor (está rota esta respnsavel por validar o usuario no banco de dados)
app.post('/autenticar', (req, res) => {
    const { email, senha, opcao } = req.body;
    const sql = 'SELECT * FROM usuarios WHERE email = ? AND senha = ? AND codigoTurma = ?';
    db.query(sql, [email, senha, opcao], (err, results) => {
        if (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            res.status(500).json({ sucesso: false, mensagem: 'Erro no servidor.' });
            return;
        }
        if (results.length > 0) {
            res.json({ sucesso: true });
        } else {
            res.json({ sucesso: false });
        }
    });
});
//Adicona (cria) uma rota no servidor (está rota esta respnsavel por cadastrar o usuario no banco de dados)
app.post('/cadastrar', (req, res) => {

        const { nomecad, Email, cpfcad, Senha, Ocupacao, Turma } = req.body;
        const sql = 'INSERT INTO usuarios (nome, email, cpf, senha, ocupacao, codigoTurma) VALUES (?, ?, ?, ?, ?, ?)';
        db.query(sql, [nomecad, Email, cpfcad, Senha, Ocupacao, Turma], (err,  results)=> {
            if(err) {
                console.error('Erro ao inserir no banco de dados:', err);
                res.status(500).json({ sucesso: false, mensagemcad: 'Erro ao cadastrar usuário.' });
                return;
            }
            console.log(results);
            if (results.affectedRows>0){
                res.json({sucesso: true})
            } else{
                res.json({sucesso: false})
            }
        });

});

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});